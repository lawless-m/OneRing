# 07 — Genericity

OneRing is a pattern, not just an invoice-copy pipeline. This doc covers what
makes it reusable for other batch decision problems.

## The shape OneRing fits

OneRing applies to any problem where:

1. **Data lives in multiple sources.** If everything's in one DB, plain SQL
   is simpler.
2. **Decisions are made periodically, not continuously.** Hourly, nightly,
   weekly batch — not real-time event streams.
3. **Decisions are gated by named, business-meaningful rules.** "Is this
   eligible / approved / overdue / suspicious?" — not "compute this number".
4. **Someone will ask 'why?' later.** Compliance, audit, customer service,
   debugging.
5. **Volume is moderate.** Thousands to low millions of rows per run, not
   billions.

Examples beyond the invoice case:

- Insurance claim auto-approval / referral
- Reconciliation: which transactions in system A match system B
- Fraud screening with explainable rules
- Eligibility checks (benefits, discounts, tier thresholds)
- Data quality: which records pass which validation rules
- Access control review: which users still meet which entitlement criteria

## The reusable pieces vs. the per-project pieces

### Reusable across projects

- The architecture (DuckDB → Datalog text → cozo-bin → results).
- The orchestrator skeleton (subprocess invocation, run directories, logging).
- Conventions: rule naming, diagnostic-relations pattern, run directory layout.
- The fact-emission helper macros (`cozo_str`, `cozo_num`, etc.).
- The schema-evolution discipline.

### Per-project

- The fact-emission SQL queries (depend on source schemas).
- The rule script itself (depends on the business logic).
- The action-execution code (depends on what the side effects are).
- Source DB connection details.

## Suggested project layout for a generic OneRing

```
onering-core/                  # the reusable bits
├── orchestrator/              # C# library: subprocess, logging, run dirs
├── duckdb-helpers/            # SQL macros for Datalog emission
├── conventions/               # rule-script templates, naming guides
└── docs/                      # the docs you're reading

onering-invoices/              # one project using OneRing
├── sql/                       # invoice-specific fact-emission queries
├── rules/                     # invoice-specific rule scripts
├── actions/                   # C# code that does the copying
└── config/

onering-claims/                # another project using OneRing
├── sql/
├── rules/
├── actions/
└── config/
```

The core is a library / CLI; each project is an instantiation that supplies
the SQL, rules, and actions.

## What stays constant across projects

- **Datalog text as wire format.** No project should be reaching for binary
  formats prematurely.
- **The rule_eval diagnostic pattern.** Every project's rules emit per-rule
  pass/fail for every record.
- **One run = one directory.** No exceptions. Makes archival, debugging, and
  shipping-context-to-a-colleague trivial.
- **No business logic in orchestrator code.** The rule script is the ONLY
  source of truth for what's eligible.

## What varies

- **Refresh cadence.** Hourly / nightly / on-demand.
- **Source mix.** One project might federate Postgres + a flat file; another
  might federate three SQL Servers.
- **Action layer complexity.** Some projects just write a report; others
  perform transactional updates.
- **Whether history matters.** A reconciliation pipeline might not care about
  long-term archive; a compliance pipeline absolutely does.

## Naming

If OneRing becomes a thing across projects, "OneRing" is the framework /
pattern. Each instantiation gets its own name — `OneRing-Invoices`,
`OneRing-Reconciliation`, etc. Keeps it clear that the framework is generic
and the deployment is specific.

## Anti-patterns to avoid

- **Don't add features to OneRing-core to support one project's quirk.** Solve
  it in that project's SQL or rules. Keep core small.
- **Don't merge multiple projects' rule files into one.** Each batch is one
  rule file. If two batches want to share predicates, factor them into a
  separate `.cozo` library file that both `:include`.
- **Don't graduate from text to binary formats prematurely.** The text
  formats are the whole point. Binary is an optimisation, only when proven
  necessary.
