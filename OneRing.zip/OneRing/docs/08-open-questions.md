# 08 — Open Questions

Decisions deferred from design to implementation, and things that will become
clearer once there's a working prototype to argue with.

## Fact emission strategy

**Question**: Strategy A (SQL-side concatenation) or Strategy B (tabular
intermediate + transformer)?

**Status**: Recommendation is A first, refactor to B if escaping pains
emerge. Worth deciding for real after the first non-trivial fact file.

## DECIMAL precision

**Question**: How are monetary amounts encoded — float, scaled int, or string?

**Stakes**: If the rules need exact equality (`amount == 100.00`), float
round-trips will bite. If they only need ranges (`amount > threshold`), float
is fine.

**Suggested default**: Encode as String, cast to Float in rules where range
comparisons are needed. Revisit if performance is an issue.

## NULL representation

**Question**: Skip NULL columns in `:put`, or emit explicit `null`?

**Status**: Recommendation is explicit `null`. Simpler emission, more
predictable rules. Confirm by testing on real data.

## Schema declarations

**Question**: Use `:create` to pre-declare relation schemas in `rules.cozo`,
or rely on Cozo's inference from `:put`?

**Trade-off**: Declared schemas catch fact-emitter bugs at load time;
inferred schemas are less code to maintain.

**Suggested default**: Declare. The cost is small and the safety is large.

## Cozo state per run: fresh or persistent?

**Question**: Does each run start from a fresh `.redb` file, or persist state
between runs?

**Argument for fresh**: Reproducibility. The run directory's `facts.cozo`
fully determines the outcome.

**Argument for persistent**: Faster (no reload), enables incremental
evaluation, lets long-lived relations like `already_copied` accumulate
naturally.

**Suggested default**: Fresh. Persistence is an optimisation; correctness
first.

## How are `already_copied` and similar facts populated?

**Question**: At fact-emission time, the rules need to know what's *already*
been copied. Where does that fact come from?

**Options**:
- Query the destination DB at run start, emit as facts.
- Maintain a local ledger that the orchestrator updates after each successful action.
- Both: query destination as authoritative, update ledger as cache.

**Suggested default**: Query the destination at the start of each run. It's
the source of truth. The local ledger is an optimisation.

## Decision output format

**Question**: Cozo's JSON output, Datalog text, or both?

**Suggested default**: Both. JSON for the orchestrator to parse; Datalog text
for the human-readable archive. Cheap to emit two formats.

## Rule-eval generation

**Question**: Are the diagnostic `rule_eval` rules written by hand, or
generated from a list of rule names?

**Trade-off**: Hand-written is more flexible but easier to forget; generated
ensures consistency but adds a build step.

**Suggested default**: Hand-written, with a code-review checklist item for
"did you add the rule_eval pair?". Revisit if the rule list grows past, say,
twenty.

## Cross-run analysis storage

**Question**: When does the historical-decisions DuckDB index get built?

**Options**:
- Live: orchestrator updates it after every run.
- Nightly: a separate job rebuilds from run directories.
- On-demand: built only when someone wants to query history.

**Suggested default**: Nightly. Keeps the hot path simple; cross-run queries
aren't time-critical.

## Action-failure behaviour

**Question**: If one of N copy actions fails, do the others proceed?

**Suggested default**: Yes, continue. Log the failure, set non-zero exit, but
don't punish the other N-1 invoices for one failure. Make this configurable.

## Dry-run mode

**Question**: Should the orchestrator have a "load facts, evaluate rules,
log decisions, but skip side effects" mode?

**Answer**: Almost certainly yes. It's free to implement (just gate the
action step) and invaluable for testing rule changes.

## Versioning the cozo-redb dependency

**Question**: How tightly does the orchestrator pin to a specific cozo-bin
version?

**Stakes**: The fork (`cozo-redb`) doesn't promise stability before 1.0. An
upgrade could change CozoScript semantics or storage format.

**Suggested default**: Pin to a specific build. Bundle the cozo-bin binary
alongside the orchestrator if Windows deployment is fragile about PATH.

## Handling fact-emission for rules that need cross-row computation

**Question**: Some rules might want "is this the largest invoice for this
customer this month?" — which requires aggregation in the source query.

**Options**:
- Compute the aggregate in DuckDB, emit as a derived fact.
- Express it in Datalog with aggregation in the rules.

**Suggested default**: Whichever is more natural. Datalog handles aggregation
fine. DuckDB is faster at it. For rules that read more naturally with
pre-computed aggregates, do them in DuckDB and emit as facts. Don't be
ideological.

## Time travel

**Question**: cozo-redb supports time-travel relations. Do we use them?

**Status**: Probably not initially. The archive of run directories is its own
form of time travel — replay any historical run by loading its facts.
Cozo's built-in time travel is more useful for live, mutating data.
