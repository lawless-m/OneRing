# 03 — Fact Emission (the trickiest part)

This is the layer that translates query results into Datalog text. It's where
all the type-encoding, escaping, and edge-case handling lives. Get this right
once and the rest of the pipeline is mechanical.

## The core idea

DuckDB SQL produces strings; those strings happen to be valid Cozo `:put`
statements. There are two reasonable implementation strategies:

### Strategy A: SQL-side concatenation

Write SQL that produces one Datalog statement per row using string functions:

```sql
COPY (
  SELECT format(
    ':put invoices {ref: %s, amount: %s, date_iso: %s, status: %s}',
    quote_literal(ref),
    amount::VARCHAR,
    quote_literal(date_iso),
    quote_literal(status)
  ) AS line
  FROM source.invoices
) TO 'facts.cozo' (FORMAT CSV, HEADER false, QUOTE '', ESCAPE '');
```

Pros: no intermediate representation, output goes straight to disk.
Cons: every type's string-encoding rules baked into every SELECT. Easy to get
wrong, especially around quotes and nulls.

### Strategy B: Tabular intermediate, transform externally

Have DuckDB emit ordinary CSV/JSON, then a small transformer (Rust, included
with the orchestrator) reads it and emits Datalog text.

Pros: type handling lives in one place, testable in isolation.
Cons: more moving parts; an extra binary in the pipeline.

### Recommendation

**Strategy A for the first cut**, with a thin layer of SQL helper macros (DuckDB
supports macros) to centralise the encoding rules. If escaping bugs become a
recurring pain, refactor to Strategy B.

DuckDB macro example:

```sql
CREATE MACRO cozo_str(s) AS '''' || replace(s, '''', '''''') || '''';
CREATE MACRO cozo_num(n) AS CASE WHEN n IS NULL THEN 'null' ELSE n::VARCHAR END;
CREATE MACRO cozo_date(d) AS '''' || strftime(d, '%Y-%m-%d') || '''';
```

Then the SELECT becomes:

```sql
SELECT format(':put invoices {ref: %s, amount: %s, date_iso: %s}',
              cozo_str(ref), cozo_num(amount), cozo_date(date))
```

Macros are versioned alongside the SQL.

## Type encoding rules

Cozo's value types and how each maps from a DuckDB column:

| DuckDB type           | Cozo representation     | Encoding rule                       |
|-----------------------|-------------------------|-------------------------------------|
| INTEGER, BIGINT       | Int                     | Direct `::VARCHAR`                  |
| DOUBLE, REAL          | Float                   | Direct, watch precision             |
| DECIMAL              | Float (or String)       | Cast to DOUBLE, or quote as string  |
| VARCHAR, TEXT         | String                  | Single-quote, escape `'` as `''`    |
| BOOLEAN               | Bool                    | `true` / `false` literal            |
| DATE                  | String (`YYYY-MM-DD`)   | `strftime(%Y-%m-%d)`, quoted        |
| TIMESTAMP             | String (ISO 8601)       | `strftime`, quoted                  |
| BLOB                  | Bytes                   | Base64-encode, prefix per Cozo docs |
| NULL                  | absent / `null`         | See below                           |
| LIST, STRUCT          | List, Json              | Serialise to Cozo literal syntax    |

**DECIMAL** deserves a flag: if the rules need to compare amounts exactly, a
float round-trip is wrong. Encode as String and compare lexicographically (zero-
padded), or push the comparison into a fixed-point scheme. Note in `08-open-questions.md`.

## NULL handling

This is the part most likely to produce surprising bugs.

DuckDB has SQL NULL. Cozo distinguishes "the relation has no tuple for this
key" from "this column has the `Null` value". They're not the same thing.

Two strategies:

1. **Skip NULL columns.** Generate `:put invoices {ref: 'X', amount: 100}` (no
   `customer:` key) when customer is NULL. Requires per-row dynamic statement
   construction — awkward in pure SQL, easier with Strategy B.
2. **Explicit `null`.** Generate `:put invoices {ref: 'X', amount: 100, customer: null}`.
   Simpler to emit. Rules then have to handle `null` explicitly.

**Recommendation**: explicit `null`. Predictable, easier to template, and forces
the rules to make NULL handling deliberate rather than accidental.

## Escaping

The pain point. Datalog string literals use `'`. Any `'` in the data must be
doubled. SQL's standard `quote_literal` (or DuckDB's equivalent) does this for
you — **use it, don't roll your own**. Backslashes, newlines, tabs, control
characters all need consideration; verify against the Cozo parser early.

Test with rows containing: apostrophes, smart-quotes, newlines, NUL bytes,
emoji, NULL itself. If your real data is unlikely to contain any of these,
include them in test fixtures anyway.

## Determinism

For the audit story to hold, the same source data must produce the same fact
file. Things that break this:

- `SELECT *` without `ORDER BY` — DuckDB's row order isn't guaranteed.
- Floating-point aggregations whose result depends on parallelism.
- `random()`, `now()`, anything time-dependent that isn't the batch timestamp.

Add `ORDER BY` to every fact-emission query. Use the batch timestamp explicitly
where the rules need "now". Treat any non-determinism as a bug.

## Schema evolution

When the source DB grows a column or the rules need a new field, both ends
need updating in lockstep. Mitigations:

- Keep the SQL queries and the rule script in the same repo, same commit.
- The rule script can declare expected relation schemas with `:create` to fail
  loudly if the fact file is wrong.
- Run the orchestrator in dry-run mode (load facts, evaluate rules, skip the
  side-effecting actions) as part of CI on every commit.

## Why this is the trickiest part

Everything else in OneRing is "shell out and move files". This step is the only
one that's actually translating between representations, and translation is
where bugs live. Worth investing in:

- A test harness that runs known fact emissions against expected outputs.
- A small set of edge-case rows (the apostrophe / NULL / unicode set above) in
  a fixture table that emission queries always include.
- Snapshot testing: emit facts, diff against committed expected output, fail
  CI on diff.
