# 04 — Rule Script

The rule script is the centre of OneRing. Everything else is plumbing. This
doc covers how to structure it so it remains readable, debuggable, and
genuinely useful as the audit artefact it's meant to be.

## Structural conventions

```
rules.cozo
│
├── # 1. Schema declarations (optional but recommended)
├── # 2. Atomic predicates (one per business rule)
├── # 3. Composite decisions (built from atomic predicates)
├── # 4. Diagnostic relations (rule_eval, populated for everything)
└── # 5. (Export queries kept in a separate file: export.cozo)
```

## Schema declarations

Cozo will infer relation shapes from `:put` statements, but declaring them up
front catches "the SQL emitter changed but the rules didn't" bugs early.

```
:create invoices {
  ref: String =>
  amount: Float,
  date_iso: String,
  customer: String,
  status: String,
}

:create approved_customers {
  customer: String,
}

:create already_copied {
  ref: String,
}
```

The `=>` separates keys from values. Keys are what you index by; values are
the columns. Choose keys deliberately — they affect query performance and
which `:put` statements update vs. insert.

## Atomic predicates

One business rule, one named relation. Resist the urge to combine.

```
# An invoice is "recent" if dated on or after the cutoff.
recent[ref] := *invoices{ref, date_iso}, date_iso >= '2026-04-01'

# An invoice is "approved" if its customer is on the approved list.
approved[ref] := *invoices{ref, customer}, *approved_customers{customer}

# An invoice is "posted" (not draft, not cancelled).
posted[ref] := *invoices{ref, status: 'POSTED'}

# An invoice is "not yet copied" if no record of copying exists.
not_yet_copied[ref] := *invoices{ref}, not *already_copied{ref}
```

Each one's name is a sentence: *"this invoice is recent"*. Each one's body is
a single logical condition. If a predicate needs a comment to explain what it
means, it's probably doing too much.

## Composite decisions

The decision rule is the conjunction of atomic predicates:

```
should_copy[ref] := recent[ref], approved[ref], posted[ref], not_yet_copied[ref]
```

That's it. The decision *is* the conjunction. If the decision logic is more
complex than this — disjunctions, exceptions, overrides — express it by adding
more atomic predicates rather than complicating this rule.

```
# Example with an override:
exempt[ref]    := *invoices{ref, status: 'INTERNAL'}
should_copy[ref] := recent[ref], approved[ref], posted[ref],
                    not_yet_copied[ref], not exempt[ref]
```

## Diagnostic relations

The whole point of OneRing: every rule's pass/fail must be queryable per
record, regardless of whether the record was selected or not.

```
# For each invoice, for each rule, was it satisfied?
rule_eval[ref, 'recent', true]   := recent[ref]
rule_eval[ref, 'recent', false]  := *invoices{ref}, not recent[ref]

rule_eval[ref, 'approved', true]   := approved[ref]
rule_eval[ref, 'approved', false]  := *invoices{ref}, not approved[ref]

rule_eval[ref, 'posted', true]   := posted[ref]
rule_eval[ref, 'posted', false]  := *invoices{ref}, not posted[ref]

rule_eval[ref, 'not_yet_copied', true]   := not_yet_copied[ref]
rule_eval[ref, 'not_yet_copied', false]  := *invoices{ref}, not not_yet_copied[ref]
```

This is repetitive. A code generator (a small script that reads the list of
rule names and emits these pairs) is reasonable; alternatively, document the
convention so it's easy to add by hand when rules are added.

The "why wasn't INV-12345 copied?" question becomes:

```
?[rule, passed] := rule_eval['INV-12345', rule, passed]
```

…which returns one row per rule, with its outcome. The failing rule(s) are the
answer.

## Comments and provenance

The rule file is going to be read by humans trying to understand "why".
Comment generously:

```
# RULE: not_yet_copied
# WHY: We refuse to copy an invoice twice. The `already_copied` relation is
# populated from a query against the destination DB at the start of each run.
# OWNER: Finance team (ticket FIN-1234)
# ADDED: 2026-04-15
not_yet_copied[ref] := *invoices{ref}, not *already_copied{ref}
```

The cost of comments is small. The cost of someone deleting a rule because
they didn't know who relied on it is large.

## Recursion (when you need it)

Datalog earns its keep when rules build on rules in non-trivial ways. Examples
that might come up:

```
# An invoice in the same batch as an excluded invoice is also excluded.
same_batch[ref1, ref2] := *invoices{ref: ref1, batch_id},
                          *invoices{ref: ref2, batch_id},
                          ref1 != ref2

contaminated[ref] := *invoices{ref, status: 'CANCELLED'}
contaminated[ref] := contaminated[other], same_batch[ref, other]

should_copy[ref] := recent[ref], approved[ref], posted[ref],
                    not_yet_copied[ref], not contaminated[ref]
```

If your problem doesn't have this shape, you don't need recursion and Datalog
is mild overkill — a CTE-per-rule structure in plain SQL would also work, with
less novelty cost. Use Datalog when the rules want to be recursive or
hierarchical.

## Versioning

The rule script lives in the repo. Every commit is a version. Tag releases
that go to production. The orchestrator records which commit hash of the rule
script was used for each run, in `run.log` — so "what rules ran at 14:00 on
April 27th?" is answerable from the archive.

## What not to do

- **Don't put I/O in the rule script.** No HTTP calls, no DB lookups, nothing
  that varies between runs except through the fact file. The rules are pure
  functions of the facts, by design.
- **Don't use Cozo's stored procedures or triggers.** They exist; we're not
  using them. The whole pipeline is stateless-per-run.
- **Don't skip the diagnostic rules.** They feel like duplication. They are
  the entire point.
