# 05 — Orchestration

The C# layer's job is small and deliberate: sequence external processes, move
files, capture logs, perform the side effects that the rules sanction. No
business logic.

## Responsibilities

1. Create a fresh per-run directory under `runs/`.
2. Invoke DuckDB to produce `facts.cozo`.
3. Concatenate facts + rules + export queries into `run.cozo`.
4. Invoke `cozo-bin` against a fresh `.redb` file with `run.cozo`.
5. Parse `decisions.cozo` (or the JSON output) for actionable outcomes.
6. Perform side-effecting actions (e.g. invoice copy operations), logging each.
7. Write `run.log` summarising the run.
8. Exit with appropriate code.

That's the whole job.

## Why C# specifically

The work environment is Windows-heavy (Windows 11 client, various Server
versions). C# integrates cleanly with that ecosystem (Task Scheduler, AD auth
to source databases, Windows event log). The existing codebase that this
replaces is C#. There's no reason to introduce a new language for the
orchestrator.

That said: the orchestrator is so thin that it could be replaced with PowerShell,
Python, or even bash if the deployment environment changed. Nothing in
OneRing's design is C#-specific.

## Process invocation pattern

Both DuckDB and cozo-bin are invoked as child processes:

- Capture stdout, stderr, exit code.
- Set a wall-clock timeout per invocation (configurable; default generous).
- Stream stderr to the log as it arrives, don't wait for completion.
- On non-zero exit: log, halt the run, exit non-zero.

Avoid getting clever with .NET DuckDB or .NET Cozo bindings. Even if a Cozo
.NET binding existed (it doesn't, for cozo-redb), the subprocess approach
keeps the integration surface trivially small and inspectable.

## Connection strings and credentials

Source DB credentials live wherever they live now (config file, Windows
credential manager, environment). The orchestrator passes them to DuckDB via
the `ATTACH` statements in the SQL files, parameterised by environment
variable.

The rules layer has no credentials and no network access. It only ever sees
the fact file. This is a security property worth preserving deliberately.

## Side-effecting actions

The decisions file says "INV-12345 should be copied". The orchestrator does
the copying. This is where transactional concerns live:

- Each action is logged before attempting and after succeeding.
- An action that fails is logged with the exception; the run continues with
  remaining actions (by default — make this configurable).
- After all actions, the orchestrator updates `already_copied` (or the
  equivalent state) in the source-of-truth location, so the next run's facts
  reflect the changes.

The decision-vs-action separation is important: the rules said yes; the
action layer is responsible for executing on that decision and reporting
outcomes. If an action fails, the rule was still right — the world just
didn't cooperate.

## Logging

`run.log` should contain at minimum:

- Run timestamp, scheduler trigger or manual.
- Rule script commit hash.
- DuckDB version, cozo-bin version.
- Each subprocess invocation: command, exit code, duration.
- Counts: facts emitted, decisions returned, actions attempted, actions
  succeeded, actions failed.
- Anything written to stderr by subprocesses.

Keep `actions.log` separate — one line per action, structured (CSV or JSON
lines), so it's easy to query historically: "show me every invoice copy
attempt in March that failed".

## Failure handling

The orchestrator's failure model is simple:

| Stage failure                | Response                                       |
|------------------------------|------------------------------------------------|
| Cannot create run directory  | Exit 1 immediately, log to system log          |
| DuckDB invocation fails      | Log, leave partial files, exit 2               |
| cozo-bin invocation fails    | Log, leave files, exit 3                       |
| Decision parsing fails       | Log, leave files, exit 4                       |
| Action(s) fail               | Log each, continue, exit 5 if any failed       |

Different exit codes let the scheduler / monitoring distinguish between
"infrastructure problem" and "logic problem" and "world didn't cooperate".

## Concurrency

Don't. One batch run at a time. If hourly is too infrequent, make it more
frequent — but never run two simultaneously. Use a lockfile in the runs
directory.

## Configurability

Things that should be config, not code:

- Source DB connection details.
- Output paths (runs directory, archive directory).
- Path to `cozo-bin` executable.
- Path to `duckdb` executable.
- Per-stage timeouts.
- Action-failure mode (continue vs. halt).
- Retention policy for runs directory before archival.

Things that should NOT be config (they belong in versioned files):

- The fact-emission SQL.
- The rule script.
- The export queries.
