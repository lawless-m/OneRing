# 06 — Audit and History

The original motivation: *"why wasn't this one included?"* This doc covers
how OneRing answers that question, immediately and six months later.

## The immediate answer

Right after a batch run, with `runs/2026-04-27T14-00/decisions.cozo` on disk:

```
$ grep INV-12345 runs/2026-04-27T14-00/decisions.cozo
:put results_rule_eval {ref: 'INV-12345', rule: 'recent', passed: true}
:put results_rule_eval {ref: 'INV-12345', rule: 'approved', passed: false}
:put results_rule_eval {ref: 'INV-12345', rule: 'posted', passed: true}
:put results_rule_eval {ref: 'INV-12345', rule: 'not_yet_copied', passed: true}
```

There it is: invoice 12345 wasn't copied because it failed the `approved` rule.
The customer wasn't on the approved list at the time of the batch.

This works because the rule script populates `rule_eval` for every invoice and
every rule, regardless of overall outcome. Diagnostic data is not a separate
debugging mode — it's always emitted.

## Six months later

The harder version: someone asks about a run from months ago. The archive
needs to support this.

Each run directory contains everything needed to answer:

- `facts.cozo` — exactly what the rules saw
- `rules.cozo` — exactly the rules that ran (and the commit hash in `run.log`)
- `decisions.cozo` — what was concluded
- `actions.log` — what was done about it

Three approaches to querying historical runs:

### Approach 1: grep

Crude but works. Run directories are text. A shell loop over `runs/2026-*/`
plus `grep` answers a lot of questions in a one-liner.

### Approach 2: load into Cozo

Spin up `cozo-bin` against the run's files:

```
$ cozo-bin run-2026-04-27T14-00.redb < archive/2026-04-27T14-00/run.cozo
> ?[rule, passed] := *results_rule_eval{ref: 'INV-12345', rule, passed}
```

Replays the entire run. Useful when you want to ask new questions of old data
that the original export didn't anticipate.

### Approach 3: index into DuckDB

Periodically (nightly?), a separate job loads recent decisions into a DuckDB
file as a queryable history:

```
historical_decisions.duckdb
├── runs (run_id, timestamp, commit_hash, fact_count, decision_count)
├── rule_evaluations (run_id, ref, rule, passed)
└── actions (run_id, ref, action, succeeded, error)
```

Now historical queries are SQL: "show me every run in March where
`not_yet_copied` was the failing rule for an invoice we later copied
manually". Cross-run analysis is where DuckDB earns its keep — Cozo is
optimised for *one* run's worth of data at a time, DuckDB for analytics
across many.

This is also where Parquet would re-enter the picture (`COPY rule_evaluations
TO 'archive.parquet'`), if long-term storage volume mattered.

## Retention

Three tiers, configurable:

| Tier      | What's kept                          | How long       |
|-----------|--------------------------------------|----------------|
| Hot       | Full run directories under `runs/`   | Last 7 days    |
| Warm      | Same, moved to `archive/`            | 90 days        |
| Cold      | Compressed tar, or Parquet summaries | Indefinitely   |

The `actions.log` and decisions metadata should be kept indefinitely (they're
small). The full fact files are bigger but still trivial at the row counts in
play. Compression will shrink them dramatically — Datalog text compresses
brilliantly.

## Reproducibility as a property

Given a run directory and a matching version of `cozo-bin`, you can replay
any run and get the same result. That's the test.

This implies:

- The orchestrator should record the cozo-bin version used (`cozo-bin --version`
  output in `run.log`).
- Major upgrades to cozo-redb should be done with awareness — keep older
  binaries around to replay older runs if needed.
- The rule-script commit hash being in the log lets you `git checkout` the
  rules of any historical run.

## What this gives you that the original codebase didn't

Originally: parameterised SQL with a `WHERE` clause. The query is reproducible,
but the *reasoning* about each row isn't surfaced anywhere.

With OneRing: every row's evaluation against every rule is a stored fact.
Querying "why" is a query, not a debugging session. The pipeline is its own
audit trail — there's no separate logging concern bolted on, because the
rules-engine output IS the logging.

That's the architectural payoff for all this ceremony. The "why not" question
that prompted this whole conversation has a one-line answer in any run
directory, ever.
