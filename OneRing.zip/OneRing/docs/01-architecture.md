# 01 — Architecture

## Layers, top to bottom

```
┌────────────────────────────────────────────────────────────────┐
│  Orchestrator (C#)                                             │
│  - Triggers batch runs (hourly cron / scheduled task)          │
│  - Shells out to duckdb and cozo-bin                           │
│  - Moves files, captures logs, reports failures                │
│  - No business logic. Plumbing only.                           │
└──────────────────────────────┬─────────────────────────────────┘
                               │
        ┌──────────────────────┴────────────────────┐
        │                                           │
        ▼                                           ▼
┌──────────────────────┐                 ┌──────────────────────┐
│  Federation (DuckDB) │                 │  Rules (cozo-redb)   │
│                      │                 │                      │
│  - Reads all sources │                 │  - Loads fact file   │
│  - Custom legacy ext │  Datalog text   │  - Evaluates rules   │
│  - postgres_scanner  │ ──────────────▶ │  - Emits decisions   │
│  - Emits :put facts  │                 │  - Single binary     │
│  - Emits archive too │                 │  - redb file backend │
└──────────┬───────────┘                 └──────────┬───────────┘
           │                                        │
           ▼                                        ▼
   ┌───────────────┐                        ┌───────────────┐
   │  Source DBs   │                        │  Decisions    │
   │  - Legacy DB  │                        │  - per-rule   │
   │  - Postgres   │                        │    pass/fail  │
   │  - others     │                        │  - per-record │
   └───────────────┘                        └───────────────┘
```

## Why three layers

Each layer speaks one language and does one job. Crossing between them happens
through plain text files, which means:

- Each layer is independently testable. Drop in a fixed fact file, run cozo-bin,
  inspect output. No mocks, no test doubles.
- Each layer is independently swappable. The orchestrator could be Python,
  bash, a scheduled task — it doesn't matter. The rules don't care.
- Each layer is independently auditable. Look at the fact file: that's what
  the rules saw. Look at the decisions file: that's what they concluded.

## Why DuckDB for federation specifically

The original codebase already does cross-database SQL queries. DuckDB's
strength is exactly that: federating heterogeneous data sources behind a single
SQL dialect. The host has a custom DuckDB extension for the legacy database
already; `postgres_scanner` covers Postgres; CSV/Parquet/JSON are native.
Whatever the source, DuckDB makes it look like a table.

It also has fast, ergonomic text emission (`COPY ... TO`, string functions like
`format`, `printf`, `concat_ws`), which matters for the fact-emission step.

## Why cozo-redb specifically

- **Embedded, pure-Rust, single binary.** No server, no daemon, no DLLs, no
  Python interpreter, no JVM. `cozo-bin` is one file you can drop on a Windows
  Server box and run. Matters when your work environment is Windows 11 / Server.
- **Datalog with stratified negation, recursion, aggregation.** Everything you
  need for non-trivial rules.
- **redb backend.** File-based, mmap, transactional, fully crash-safe. The
  whole rules database is one file you can copy, version, archive.
- **Already a familiar codebase.** The `cozo-redb` fork is under your control,
  so any future feature (Parquet ingest, custom system ops) is in scope.
- **WASM build available.** Same rules can run in a browser for what-if
  scenarios or a debugging UI later, without rewriting them.

## Why Datalog text as the interchange

A pragmatic decision born from rejecting alternatives:

- **JSON** would need a schema and a translation layer at both ends.
- **Parquet** would need an import/export feature added to cozo-redb, and is
  overkill at thousands-of-rows scale.
- **Cozo's binary backup format** isn't human-readable.
- **Datalog text** is what cozo-bin already eats and emits. No translation. The
  fact file is itself a valid Cozo script. You can `cat`, `grep`, `diff` it.

The trade-off — verbosity, type-encoding-via-strings — is acceptable at the
scale this is built for (low thousands of rows per batch).

## What lives where

| Artefact            | Format         | Lifetime      | Inspectable with     |
|---------------------|----------------|---------------|----------------------|
| Source data         | (Various DBs)  | -             | Native client tools  |
| Federation queries  | `.sql`         | Versioned     | Any text editor      |
| Rule script         | `.cozo`        | Versioned     | Any text editor      |
| Per-batch facts     | `.cozo` text   | Retained      | `cat`, `grep`, Cozo  |
| Per-batch decisions | `.cozo` text   | Retained      | `cat`, `grep`, Cozo  |
| Cozo state          | `.redb` file   | Per run / TTL | `cozo-bin`           |
| Run logs            | text           | Retained      | `cat`, `grep`        |

## What this architecture deliberately doesn't do

- **No long-running service.** Each batch is a fresh process tree. Fewer things
  to monitor, restart, or worry about.
- **No persistent Cozo database between runs (by default).** Each run starts
  from facts loaded from DuckDB. Reproducibility is a property of the input
  files, not of accumulated state. (See `06-audit-and-history.md` for the
  archival side, which is separate.)
- **No clever in-process bindings.** C# shells out. The integration surface is
  "files in, files out, exit code".
