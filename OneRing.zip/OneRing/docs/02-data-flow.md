# 02 — Data Flow

A walk-through of one hourly batch run, from trigger to archive.

## Sequence

```
T+0s    Scheduler fires C# orchestrator
T+0s    Orchestrator creates runs/2026-04-27T14-00/ directory
T+0s    Orchestrator invokes DuckDB with fact-emission queries
T+~5s   DuckDB writes runs/.../facts.cozo
T+~5s   Orchestrator concatenates: facts.cozo + rules.cozo + export.cozo
        → run.cozo
T+~5s   Orchestrator invokes cozo-bin with run.cozo against fresh redb file
T+~10s  cozo-bin loads facts, evaluates rules, writes decisions.cozo
T+~10s  Orchestrator parses decisions.cozo for outcomes that need acting on
T+~15s  Orchestrator performs the side-effecting actions (e.g. invoice copies)
T+~15s  Orchestrator writes run.log and exits
T+~15s  (Async) Archival job moves runs/.../* to archive/ once stable
```

Numbers are illustrative — a thousands-of-rows batch should be well inside this.

## Per-run directory layout

```
runs/2026-04-27T14-00/
├── facts.cozo           # emitted by DuckDB
├── rules.cozo           # copied from versioned rules/ at run time
├── export.cozo          # the queries that emit decisions (versioned)
├── run.cozo             # concatenation of the above three
├── decisions.cozo       # cozo-bin output
├── actions.log          # what the orchestrator did about the decisions
└── run.log              # everything else: timings, exit codes, stderr
```

Keeping each run self-contained is deliberate: an entire batch is one
directory, easy to copy, ship to a colleague, or attach to a ticket.

## What each file looks like (sketch)

### `facts.cozo`

```
:put invoices {ref: 'INV-12345', amount: 1250.00, date_iso: '2026-04-27', customer: 'C001', status: 'POSTED'}
:put invoices {ref: 'INV-12346', amount: 89.50, date_iso: '2026-04-27', customer: 'C002', status: 'DRAFT'}
:put already_copied {ref: 'INV-12300'}
:put already_copied {ref: 'INV-12301'}
:put approved_customers {customer: 'C001'}
...
```

One `:put` per row. Relations declared with implicit schema on first put, or
pre-declared in `rules.cozo` if strict schema is wanted.

### `rules.cozo`

```
# Each rule named, single responsibility, composable.

recent[ref] := *invoices{ref, date_iso}, date_iso >= '2026-04-01'

approved[ref] := *invoices{ref, customer}, *approved_customers{customer}

posted[ref] := *invoices{ref, status: 'POSTED'}

not_yet_copied[ref] := *invoices{ref}, not *already_copied{ref}

# The decision rule. All conditions must hold.
should_copy[ref] := recent[ref], approved[ref], posted[ref], not_yet_copied[ref]

# Diagnostic relations — populated regardless of overall outcome.
rule_eval[ref, 'recent', true]  := recent[ref]
rule_eval[ref, 'recent', false] := *invoices{ref}, not recent[ref]
rule_eval[ref, 'approved', true]  := approved[ref]
rule_eval[ref, 'approved', false] := *invoices{ref}, not approved[ref]
# ... etc for each rule
```

### `export.cozo`

```
?[ref] := should_copy[ref]
:replace results_should_copy {ref}

?[ref, rule, passed] := rule_eval[ref, rule, passed]
:replace results_rule_eval {ref, rule => passed}
```

### `decisions.cozo`

The cozo-bin output, structured so the orchestrator can parse it. Either
Cozo's JSON output mode, or a `:export` of the result relations as Cozo text.
Recommendation: **JSON for machine consumption, separate Cozo text dump for
human reading and archive**. Both are cheap to emit.

## Failure modes and where they surface

| Failure                              | Surfaces as                          |
|--------------------------------------|--------------------------------------|
| Source DB unreachable                | DuckDB exits non-zero, logged        |
| Fact emission produces malformed text| cozo-bin parse error, logged         |
| Rule script has a syntax error       | cozo-bin parse error, logged         |
| Rule produces wrong shape            | Export query fails, logged           |
| Side-effecting action fails          | Orchestrator log, partial actions.log|

The orchestrator's job on any failure is: log it, leave the run directory in
place for inspection, exit non-zero so the scheduler / monitoring sees it.

## Idempotency

A re-run of a given hour with the same source data should produce the same
`facts.cozo` and the same `decisions.cozo`. This is the test for whether the
fact-emission queries are deterministic (e.g. ordering, NULL handling). See
`03-fact-emission.md` for why this matters.

The side-effecting actions step is the only non-idempotent part — and that's
gated by the `not_yet_copied` rule, which is exactly the right place to enforce
it.
