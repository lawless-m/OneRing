# OneRing — Contents

A declarative rules pipeline that surfaces business logic as inspectable Datalog,
backed by DuckDB for federated source access and cozo-redb for rule evaluation.

## Where to start

1. **`README.md`** — what OneRing is, why it exists, the one-paragraph version.
2. **`docs/01-architecture.md`** — the full picture, layer by layer, end to end.
3. **`docs/02-data-flow.md`** — how a single batch run progresses through the system.
4. **`docs/03-fact-emission.md`** — the DuckDB → Datalog text translation. **The trickiest part.**
5. **`docs/04-rule-script.md`** — how rules are structured, named, versioned, surfaced.
6. **`docs/05-orchestration.md`** — the C# layer's responsibilities.
7. **`docs/06-audit-and-history.md`** — the "why wasn't this included?" story.
8. **`docs/07-genericity.md`** — what makes OneRing reusable beyond the invoice case.
9. **`docs/08-open-questions.md`** — decisions deferred to implementation time.

## File layout once built

```
onering/
├── rules/                    # versioned .cozo files — THE business logic
├── orchestrator/             # C# project — DuckDB invocation, cozo-bin shell-out
├── sql/                      # DuckDB queries that emit Datalog facts
├── runs/                     # per-batch outputs (facts, decisions, logs)
└── archive/                  # long-term retention
```

## Conventions used in these docs

- **Concrete > abstract.** Examples use the invoice-copy use case throughout, with
  a separate doc (`07-genericity.md`) explaining how to lift the pattern.
- **No code until asked.** These are design docs. Claude Code does the implementation.
- **UK English, metric where applicable.**
