# OneRing

> *One ring to rule them all, one ring to find them, one ring to bring them all,
> and in the Datalog bind them.*

OneRing is a pattern (and an implementation) for batch pipelines whose decisions
need to be **explainable after the fact**. It surfaces the rules that gate a
decision as first-class, versioned, human-readable artefacts rather than burying
them in imperative code or parameterised SQL `WHERE` clauses.

## The problem it solves

You have a batch job that decides whether records cross some threshold —
whether an invoice should be copied to another system, whether a claim should be
auto-approved, whether a transaction is suspicious. The logic lives somewhere:
in C# `if` statements, in SQL `WHERE` clauses, in a procedural script.

Six months later, someone asks: *"Why wasn't this one included?"*

You have the parameterised query. You don't have the answer.

## The shape of the solution

OneRing breaks the pipeline into three layers, each speaking a single language:

1. **Federation** (DuckDB) — pulls facts from heterogeneous sources into one place.
2. **Rules** (Datalog, evaluated by cozo-redb) — declares the conditions, named
   and composable, that determine inclusion.
3. **Orchestration** (C#, or any host) — sequences the layers and persists results.

Facts flow between layers as **Datalog text**. Every stage is human-readable,
diffable, greppable, version-controllable. The rule file is the centre of
gravity: the only part of the system that's *logic* rather than data or plumbing.

## Why this stack

- **DuckDB** federates anything (Postgres via `postgres_scanner`, SQL Server via
  bespoke extensions, Parquet, CSV, the lot) and emits text efficiently.
- **cozo-redb** is a pure-Rust, embedded, single-file Datalog database — no
  server, no daemon, no port. Ships as one binary. Ideal for a batch pipeline.
- **Datalog text as the wire format** means no schema-mapping layer, no binary
  formats to inspect with special tools, and inputs that are themselves valid
  Cozo scripts.

## What it isn't

- Not a real-time system. Hourly-batch shape.
- Not a replacement for SQL. SQL still lives in DuckDB doing what it's good at.
- Not a graph database story, despite Cozo's graph credentials. We use the
  Datalog and the explainability; the graph algorithms are a bonus if needed.

## Status

Design phase. See `CONTENTS.md` for navigation through the design docs.
